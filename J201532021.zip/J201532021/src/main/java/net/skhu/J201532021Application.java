package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class J201532021Application {

	public static void main(String[] args) {
		SpringApplication.run(J201532021Application.class, args);
	}

}
